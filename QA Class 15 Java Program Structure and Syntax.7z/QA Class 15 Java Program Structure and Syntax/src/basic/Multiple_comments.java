package basic;

public class Multiple_comments {

	public static void main(String[] args) {
		

		System.out.println("Welcome to Janbask training");
		
		System.out.println("Selenium is automation tool");
		
		System.out.println("Java is a programming language");
		
		//Shortcut to select multiple lines to be commented is press ctrl+shift+\
		// to uncomment select multiple lines which is commented press ctrl+shift+/

		
		/*
		 * System.out.println("Welcome to Janbask training");
		 * 
		 * System.out.println("Selenium is automation tool");
		 * 
		 * System.out.println("Java is a programming language");
		 * 
		 * 
		 * System.out.println("Welcome to Janbask training");
		 * 
		 * System.out.println("Selenium is automation tool");
		 * 
		 * System.out.println("Java is a programming language");
		 * 
		 * System.out.println("Welcome to Janbask training");
		 * 
		 * System.out.println("Selenium is automation tool");
		 * 
		 * 
		 * System.out.println("Java is a programming language");
		 * 
		 * 
		 * 
		 * System.out.println("Welcome to Janbask training");
		 * 
		 * System.out.println("Selenium is automation tool");
		 * 
		 * System.out.println("Java is a programming language");
		 * 
		 * System.out.println("Welcome to Janbask training");
		 * 
		 * System.out.println("Selenium is automation tool");
		 * 
		 * System.out.println("Java is a programming language");
		 */
		
		
		

	}

}
