package basic;

public class Comments {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Welcome");
		//System.out.println("Selenium");
		//System.out.println("Java");
		//System.out.println("Janbask");
		
   //      System.out.println("Welcome to Janbask training");
		
	//	System.out.println("Selenium is automation tool");
		
	//	System.out.println("Java is a programming language");


	}

}
