package basic;

public class Print_Ex {

	public static void main(String[] args) 
	
	{
		// TODO Auto-generated method stub
		
		
		System.out.println("Welcome to Janbask training");
		
		System.out.println("Selenium is automation tool");
		
		System.out.println("Java is a programming language");

	}

}
