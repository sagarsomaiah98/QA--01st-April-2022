package basic;

public class PrintVsPrintln {
	
	
	public static void main(String[] args) 
	
	
	
	{
		
		System.out.println("Welcome"); //  System.out.println prints and also creates a new line
		System.out.println("Selenium");
		System.out.print("Java");  // System.out.print prints and doesnt create a new line
		System.out.println("Janbask");
		
		
	}

}
