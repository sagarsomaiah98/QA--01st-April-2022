package Variables;

public class Concat {

	public static void main(String[] args) {
		int age=30;
		String name="Peter";
		
		double salary= 200.50;
		
		// Peter whose age is 30 has salary 200.50
		
		
		System.out.println(name+" whose age is "+age+" has salary "+salary);
		
		

	}

}
