package Variables;

public class Variable_Ex {

	public static void main(String[] args) {
		
		//Integer
		
		
		int a=10;
		int b=20;
		System.out.println("b");
		
		   double c=10.93;
		   System.out.println(c);
		   
    char m='P';		
    System.out.println(m);
    
  String  value="Welcome to training";
		System.out.println(value);
		
		boolean t=true;
		boolean f= false;
		
		System.out.println(t);
		System.out.println(f);
		
	}

}
