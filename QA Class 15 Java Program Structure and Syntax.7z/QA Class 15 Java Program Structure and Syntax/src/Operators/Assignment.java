package Operators;

public class Assignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int a=20;
		
		int b=30;
		
		String value="John";
		
		System.out.println(a+b);
		System.out.println(a+b+value);
		
		System.out.println(a+value+b);
		
		System.out.println(value+a+b);
		
	}

}
