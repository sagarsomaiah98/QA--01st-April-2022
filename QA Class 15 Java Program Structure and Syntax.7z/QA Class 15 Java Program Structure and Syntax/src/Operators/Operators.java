package Operators;

public class Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=25;
		
		int b=10;
		
		int c= a+b;
		int d= a-b;
		int e= a*b;
		int f= a/b;
		int k=a%b;
		
		System.out.println(c);//30
		System.out.println(d);//10
		System.out.println(e);//200
		System.out.println(f);//2
		System.out.println(k);//Remainder 0
		
		
		
		
		
		

	}

}
